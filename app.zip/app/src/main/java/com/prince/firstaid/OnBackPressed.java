package com.prince.firstaid;

interface OnBackPressed {
}
