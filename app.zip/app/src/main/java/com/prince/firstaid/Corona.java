package com.prince.firstaid;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;
import android.widget.Toolbar;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.android.material.tabs.TabLayout;

public class Corona extends AppCompatActivity {
    private ViewPagerAdapter viewPagerAdapter;
    private TabLayout tabLayout;
    private ViewPager viewPager;
    private Toolbar toolbar;
    private AdView adView2;
    private InterstitialAd interstitialAd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_corona2);




        //Tabbed Activity
        tabLayout = findViewById(R.id.tablayout);
        viewPager = findViewById(R.id.viewPager);
        viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());

        //viewPagerAdapter
        viewPagerAdapter.AddFragment(new fragment1(), "Hello");
        viewPagerAdapter.AddFragment(new fragment7(), "test");

        viewPagerAdapter.AddFragment(new fragment2(), "Prince");
        viewPagerAdapter.AddFragment(new fragment3(), "Kasaudhan");
        viewPagerAdapter.AddFragment(new fragment4(), "Kasaudhan");
        viewPagerAdapter.AddFragment(new fragment5(), "Kasaudhan");

        viewPager.setAdapter(viewPagerAdapter);

        tabLayout.setupWithViewPager(viewPager);
        tabLayout.getTabAt(0).setText("CORONA AWARENESS");
        tabLayout.getTabAt(1).setText("Test Yourself");
        tabLayout.getTabAt(2).setText("INSTRUCTION");
        tabLayout.getTabAt(3).setText("PRECAUTION");
        tabLayout.getTabAt(4).setText("MYTHS");
        tabLayout.getTabAt(5).setText("CONTACT");



    }
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater menuInflater = getMenuInflater();      // it inflate the menu item in the code and its xml file will be too inflated
        menuInflater.inflate(R.menu.menus, menu);

        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);

         if (item.getItemId() == R.id.About) {
            Intent intent = new Intent(getApplicationContext(), feedback.class);
            startActivity(intent);


            return true;
        }


        else if (item.getItemId() == R.id.setting) {

            Intent intent = new Intent(getApplicationContext(), Important.class);
            startActivity(intent);

            return true;
        }




        return false;
    }
    @Override
    public void onBackPressed() {

        if (interstitialAd.isLoaded()) {
            interstitialAd.show();
            interstitialAd.setAdListener(new AdListener() {
                @Override
                public void onAdClosed() {
                    super.onAdClosed();
                    finish();
                }
            });
        } else {
            Toast.makeText(this, "Thank You", Toast.LENGTH_SHORT).show();
            super.onBackPressed();
        }
    }
      }