package com.prince.firstaid;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;

public class Myths extends AppCompatActivity {
    private AdView adView2;
    private InterstitialAd interstitialAd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myths);
        MobileAds.initialize(this, "ca-app-pub-5987730059541217~5470442932");
        adView2 =
                findViewById(R.id.adView1);
        AdRequest adRequest1 = new AdRequest.Builder().build();
        adView2.loadAd(adRequest1);
        interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(("ca-app-pub-5987730059541217/3439369488"));
        AdRequest adRequest5 = new AdRequest.Builder().build();
        interstitialAd.loadAd(adRequest5);

    }
    @Override
    public void onBackPressed() {

        if (interstitialAd.isLoaded()) {
            interstitialAd.show();
            interstitialAd.setAdListener(new AdListener() {
                @Override
                public void onAdClosed() {
                    super.onAdClosed();
                    finish();
                }
            });
        } else {
            Toast.makeText(this, "Thank You", Toast.LENGTH_SHORT).show();
            super.finish();

        }
    }
}
