package com.prince.firstaid;


import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;

public class fragment3 extends Fragment {
    private AdView adView2;
    private InterstitialAd interstitialAd;
View view;
    public fragment3() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
      view= inflater.inflate(R.layout.fragment_fragment4, container, false);
        MobileAds.initialize(getActivity(), "ca-app-pub-5987730059541217~5470442932");
        adView2 = view.findViewById(R.id.adView1);
        AdRequest adRequest1 = new AdRequest.Builder().build();
        adView2.loadAd(adRequest1);
        interstitialAd = new InterstitialAd(getActivity());
        interstitialAd.setAdUnitId(("ca-app-pub-5987730059541217/3439369488"));
        AdRequest adRequest5 = new AdRequest.Builder().build();
        interstitialAd.loadAd(adRequest5);

        return view;
    }
    @Override
    public void onResume() {
        super.onResume();

        getView().setFocusableInTouchMode(true);
        getView().requestFocus();
        getView().setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {

                    if(interstitialAd.isLoaded())
                    {
                        interstitialAd.show();
                        interstitialAd.setAdListener(new AdListener()
                        {
                            @Override
                            public void onAdClosed(){
                                super.onAdClosed();
                                getActivity().finish();

                            }
                        });
                    }
                    else {
                        Toast.makeText(getActivity(), "Thank You", Toast.LENGTH_SHORT).show();
                        getActivity().finish();
                    }


                    // handle back button's click listener

                    Toast.makeText(getActivity(), "Back press", Toast.LENGTH_SHORT).show();
                    return true;
                }
                return false;
            }
        });

    }

}
