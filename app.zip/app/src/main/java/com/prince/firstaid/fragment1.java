package com.prince.firstaid;


import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;


/**
 * A simple {@link Fragment} subclass.
 */
public class fragment1 extends Fragment{

private ImageButton imageButton1;
    private ImageButton imageButton2;
    private ImageButton imageButton3;
    private ImageButton imageButton4;
    private ImageButton imageButton5;
    private ImageButton imageButton6;
    private AdView adView2;
    private InterstitialAd interstitialAd;

    View view;

    public fragment1() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view= inflater.inflate(R.layout.fragment_fragment1, container, false);
        MobileAds.initialize(getActivity(), "ca-app-pub-5987730059541217~5470442932");
        adView2 = view.findViewById(R.id.adView1);
        AdRequest adRequest1 = new AdRequest.Builder().build();
        adView2.loadAd(adRequest1);
        interstitialAd = new InterstitialAd(getActivity());
        interstitialAd.setAdUnitId(("ca-app-pub-5987730059541217/3439369488"));
        AdRequest adRequest5 = new AdRequest.Builder().build();
        interstitialAd.loadAd(adRequest5);


        imageButton1=view.findViewById(R.id.imageButton3);
        imageButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(),History.class);
                startActivity(i);
            }
        });
        imageButton2=view.findViewById(R.id.imageButton4);
        imageButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(),Covid19.class);
                startActivity(i);
            }
        });
        imageButton3=view.findViewById(R.id.imageButton5);
        imageButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(),Origins.class);
                startActivity(i);
            }
        });
        imageButton4=view.findViewById(R.id.imageButton6);
        imageButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(),Harmful.class);
                startActivity(i);
            }
        });
        imageButton5=view.findViewById(R.id.imageButton7);
        imageButton5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(),More.class);
                startActivity(i);
            }
        });
        imageButton6=view.findViewById(R.id.imageButton8);
        imageButton6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(),qna.class);
                startActivity(i);
            }
        });





        return view;
    }
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
@Override
public void onResume() {
    super.onResume();

    getView().setFocusableInTouchMode(true);
    getView().requestFocus();
    getView().setOnKeyListener(new View.OnKeyListener() {
        @Override
        public boolean onKey(View v, int keyCode, KeyEvent event) {
            if (event.getAction() == KeyEvent.ACTION_UP && keyCode == KeyEvent.KEYCODE_BACK) {

                if(interstitialAd.isLoaded())
                {
                    interstitialAd.show();
                    interstitialAd.setAdListener(new AdListener()
                    {
                        @Override
                        public void onAdClosed(){
                            super.onAdClosed();
                            getActivity().finish();
                        }


                    });
                }
                else {
                    Toast.makeText(getActivity(), "Thank You", Toast.LENGTH_SHORT).show();
                    getActivity().finish();
                }


                // handle back button's click listener

                Toast.makeText(getActivity(), "Back press", Toast.LENGTH_SHORT).show();
                return true;
            }
            return false;
        }
    });

}


}
