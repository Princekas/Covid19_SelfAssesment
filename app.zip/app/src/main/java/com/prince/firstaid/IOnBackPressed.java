package com.prince.firstaid;

interface IOnBackPressed {
    boolean onBackPressed();
}
